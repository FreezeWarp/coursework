/**
 * Created by joseph on 1/20/17.
 */
public enum AccountTypeEnum {
    CHECKING_ACCOUNT,
    SAVINGS_ACCOUNT,
}
